#include "GlobeView.h"
#include <gl/GLU.h>
#include <exception>

IMPLEMENT_DYNCREATE(CGlobeView,CView)
BEGIN_MESSAGE_MAP(CGlobeView,CView)
    ON_WM_CREATE()
    ON_WM_DESTROY()
    ON_WM_SIZE()
    ON_WM_ERASEBKGND()
    ON_WM_LBUTTONDOWN()
    ON_WM_LBUTTONUP()
    ON_WM_MOUSEMOVE()
    ON_WM_MOUSEWHEEL()
    ON_WM_KEYDOWN()
    ON_WM_CAPTURECHANGED()
END_MESSAGE_MAP()
CGlobeView::~CGlobeView() { ReleaseGL(); }
BOOL CGlobeView::PreCreateWindow(CREATESTRUCT& cs) {
    if(!CView::PreCreateWindow(cs)) return FALSE;
    cs.style|=WS_CLIPSIBLINGS|WS_CLIPCHILDREN;
    cs.lpszClass=AfxRegisterWndClass(CS_OWNDC|CS_HREDRAW|CS_VREDRAW,
        ::LoadCursor(nullptr,IDC_ARROW),nullptr,nullptr);
    return cs.lpszClass!=nullptr;
}
int CGlobeView::OnCreate(LPCREATESTRUCT cs) {
    if(CView::OnCreate(cs)==-1) return -1;
    try {
        if(!InitGL()) throw std::runtime_error("OpenGL context initialization failed");
        heights_=geo::syntheticGrid();
        globeList_=CompileMesh(geo::globe());
        RebuildTerrain();
        UpdateTitle();
    } catch(const std::exception&) {
        AfxMessageBox(L"OpenGL 초기화 또는 메시 생성 실패. 그래픽 드라이버와 픽셀 포맷을 확인하세요.");
        ReleaseGL(); return -1;
    }
    return 0;
}
bool CGlobeView::InitGL() {
    dc_=::GetDC(m_hWnd);
    if(!dc_) return false;
    PIXELFORMATDESCRIPTOR pfd{};
    pfd.nSize=sizeof(pfd); pfd.nVersion=1;
    pfd.dwFlags=PFD_DRAW_TO_WINDOW|PFD_SUPPORT_OPENGL|PFD_DOUBLEBUFFER;
    pfd.iPixelType=PFD_TYPE_RGBA; pfd.cColorBits=24; pfd.cDepthBits=24;
    pfd.iLayerType=PFD_MAIN_PLANE;
    int format=ChoosePixelFormat(dc_,&pfd);
    if(!format||!SetPixelFormat(dc_,format,&pfd)) return false;
    PIXELFORMATDESCRIPTOR actual{};
    if(!DescribePixelFormat(dc_,format,sizeof(actual),&actual) ||
       actual.cDepthBits<16 || !(actual.dwFlags&PFD_DOUBLEBUFFER)) return false;
    rc_=wglCreateContext(dc_);
    if(!rc_||!wglMakeCurrent(dc_,rc_)) return false;
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE); glCullFace(GL_BACK); glFrontFace(GL_CCW);
    glEnable(GL_NORMALIZE); glEnable(GL_LIGHTING); glEnable(GL_LIGHT0);
    glEnable(GL_COLOR_MATERIAL);
    glColorMaterial(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE);
    const GLfloat ambient[]={0.32f,0.32f,0.32f,1};
    glLightModelfv(GL_LIGHT_MODEL_AMBIENT,ambient);
    glClearColor(0.018f,0.025f,0.055f,1);
    return true;
}
void CGlobeView::ReleaseGL() {
    if(rc_) {
        if(dc_ && wglMakeCurrent(dc_,rc_)) {
            if(globeList_) glDeleteLists(globeList_,1);
            if(terrainList_) glDeleteLists(terrainList_,1);
            wglMakeCurrent(nullptr,nullptr);
        }
        wglDeleteContext(rc_); rc_=nullptr;
        globeList_=terrainList_=0;
    }
    if(dc_) { if(m_hWnd) ::ReleaseDC(m_hWnd,dc_); dc_=nullptr; }
}
void CGlobeView::OnDestroy() { ReleaseGL(); CView::OnDestroy(); }
GLuint CGlobeView::CompileMesh(const geo::Mesh& mesh) {
    GLuint id=glGenLists(1);
    if(!id) throw std::runtime_error("glGenLists failed");
    glNewList(id,GL_COMPILE);
    glBegin(GL_TRIANGLES);
    for(auto idx:mesh.indices) {
        const auto& v=mesh.vertices[idx];
        glColor3f(v.r,v.g,v.b);
        glNormal3d(v.normal.x,v.normal.y,v.normal.z);
        glVertex3d(v.position.x,v.position.y,v.position.z);
    }
    glEnd(); glEndList();
    return id;
}
void CGlobeView::RebuildTerrain() {
    auto mesh=geo::terrain(heights_,exaggeration_);
    GLuint next=CompileMesh(mesh);
    if(terrainList_) glDeleteLists(terrainList_,1);
    terrainList_=next;
}
void CGlobeView::OnDraw(CDC* dc) { if(!dc->IsPrinting()) Render(); }
BOOL CGlobeView::OnEraseBkgnd(CDC*) { return TRUE; }
void CGlobeView::OnSize(UINT type,int cx,int cy) {
    CView::OnSize(type,cx,cy);
    width_=std::max(1,cx); height_=std::max(1,cy);
    if(rc_) Invalidate(FALSE);
}
void CGlobeView::DrawGrid() {
    glDisable(GL_LIGHTING); glColor3f(0.18f,0.42f,0.60f);
    auto point=[](double lon,double lat) {
        auto p=geo::position(lon,lat,1000);
        glVertex3d(p.x,p.y,p.z);
    };
    for(int lat=-75;lat<=75;lat+=15) {
        glBegin(GL_LINE_STRIP);
        for(int lon=-180;lon<=180;++lon) point(lon,lat);
        glEnd();
    }
    for(int lon=-180;lon<180;lon+=15) {
        glBegin(GL_LINE_STRIP);
        for(int lat=-90;lat<=90;++lat) point(lon,lat);
        glEnd();
    }
    glEnable(GL_LIGHTING);
}
void CGlobeView::Render() {
    if(!rc_||!wglMakeCurrent(dc_,rc_)) return;
    glViewport(0,0,width_,height_);
    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION); glLoadIdentity();
    // Tighten depth range in globe mode; local mode requires a smaller near plane.
    double nearPlane=local_ ? std::max(0.5,distance_*0.001) : std::max(1.0,(distance_-geo::RadiusKm)*0.25);
    gluPerspective(45,double(width_)/height_,nearPlane,distance_+geo::RadiusKm*3);
    glMatrixMode(GL_MODELVIEW); glLoadIdentity();
    const GLfloat light[]={-0.3f,0.6f,1.0f,0.0f};
    glLightfv(GL_LIGHT0,GL_POSITION,light); // headlight in eye coordinates
    geo::Vec3 eye,target,up;
    if(local_) {
        target=geo::position(128,36,1000*exaggeration_);
        auto radial=geo::unit(geo::position(128,36));
        double l=128*geo::Pi/180;
        geo::Vec3 east{-std::sin(l),std::cos(l),0};
        auto north=geo::cross(radial,east);
        double a=azimuth_*geo::Pi/180,t=tilt_*geo::Pi/180;
        auto horizontal=north*std::cos(a)+east*std::sin(a);
        eye=target+(radial*std::cos(t)+horizontal*std::sin(t))*distance_;
        up=radial*std::sin(t)-horizontal*std::cos(t);
    } else {
        auto radial=geo::unit(geo::position(lon_,lat_));
        eye=radial*distance_; target={0,0,0}; up={0,0,1};
    }
    gluLookAt(eye.x,eye.y,eye.z,target.x,target.y,target.z,up.x,up.y,up.z);
    glCallList(globeList_);
    glPolygonMode(GL_FRONT_AND_BACK,wire_?GL_LINE:GL_FILL);
    glCallList(terrainList_);
    glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
    if(grid_) DrawGrid();
    SwapBuffers(dc_);
}
void CGlobeView::OnLButtonDown(UINT flags,CPoint p) {
    SetFocus(); SetCapture(); dragging_=true; last_=p;
    CView::OnLButtonDown(flags,p);
}
void CGlobeView::OnLButtonUp(UINT flags,CPoint p) {
    dragging_=false; if(GetCapture()==this) ReleaseCapture();
    CView::OnLButtonUp(flags,p);
}
void CGlobeView::OnCaptureChanged(CWnd* wnd) { dragging_=false; CView::OnCaptureChanged(wnd); }
void CGlobeView::OnMouseMove(UINT flags,CPoint p) {
    if(dragging_) {
        double dx=(p.x-last_.x)*0.3,dy=(p.y-last_.y)*0.3;
        if(local_) { azimuth_+=dx; tilt_=std::clamp(tilt_+dy,0.0,65.0); }
        else { lon_-=dx; lat_=std::clamp(lat_+dy,-85.0,85.0); }
        last_=p; Invalidate(FALSE);
    }
    CView::OnMouseMove(flags,p);
}
BOOL CGlobeView::OnMouseWheel(UINT,short delta,CPoint) {
    double factor=std::pow(0.85,double(delta)/WHEEL_DELTA);
    distance_=std::clamp(distance_*factor,local_?400.0:geo::RadiusKm+250.0,local_?5000.0:60000.0);
    Invalidate(FALSE); return TRUE;
}
void CGlobeView::OnKeyDown(UINT key,UINT repeat,UINT flags) {
    switch(key) {
    case '1': local_=false; distance_=20000; lon_=128; lat_=36; break;
    case '2': local_=true; distance_=1500; azimuth_=0; tilt_=30; break;
    case 'W': wire_=!wire_; break;
    case 'G': grid_=!grid_; break;
    case 'E':
        if(wglMakeCurrent(dc_,rc_)) {
            double previous=exaggeration_;
            exaggeration_=(exaggeration_==1?20:1);
            try { RebuildTerrain(); }
            catch(const std::exception&) { exaggeration_=previous; AfxMessageBox(L"지형 재생성 실패"); }
        }
        break;
    default: CView::OnKeyDown(key,repeat,flags); return;
    }
    UpdateTitle(); Invalidate(FALSE);
}
void CGlobeView::UpdateTitle() {
    if(auto* frame=GetParentFrame()) {
        CString title;
        title.Format(L"MFC OpenGL GIS | %s | 가상 지형 x%.0f | 1:지구 2:지형 W:격자 G:경위선 E:고도배율 | 드래그/휠",
            local_?L"지형 확대":L"지구 전체",exaggeration_);
        frame->SetWindowText(title);
    }
}
