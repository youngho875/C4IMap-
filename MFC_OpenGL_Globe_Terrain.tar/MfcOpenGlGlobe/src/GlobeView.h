#pragma once
#include <afxwin.h>
#include <gl/GL.h>
#include "Geometry.h"

class CGlobeView : public CView {
    DECLARE_DYNCREATE(CGlobeView)
public:
    CGlobeView() = default;
    ~CGlobeView() override;
    BOOL PreCreateWindow(CREATESTRUCT& cs) override;
    void OnDraw(CDC*) override;
protected:
    afx_msg int OnCreate(LPCREATESTRUCT cs);
    afx_msg void OnDestroy();
    afx_msg void OnSize(UINT type,int cx,int cy);
    afx_msg BOOL OnEraseBkgnd(CDC*);
    afx_msg void OnLButtonDown(UINT flags,CPoint p);
    afx_msg void OnLButtonUp(UINT flags,CPoint p);
    afx_msg void OnMouseMove(UINT flags,CPoint p);
    afx_msg BOOL OnMouseWheel(UINT flags,short delta,CPoint p);
    afx_msg void OnKeyDown(UINT key,UINT repeat,UINT flags);
    afx_msg void OnCaptureChanged(CWnd* wnd);
    DECLARE_MESSAGE_MAP()
private:
    HDC dc_=nullptr;
    HGLRC rc_=nullptr;
    GLuint globeList_=0,terrainList_=0;
    int width_=1,height_=1;
    bool dragging_=false,local_=false,wire_=false,grid_=true;
    CPoint last_;
    double lon_=128,lat_=36,distance_=20000,azimuth_=0,tilt_=30,exaggeration_=20;
    geo::HeightGrid heights_;
    bool InitGL();
    void ReleaseGL();
    void RebuildTerrain();
    static GLuint CompileMesh(const geo::Mesh& mesh);
    void Render();
    void DrawGrid();
    void UpdateTitle();
};
