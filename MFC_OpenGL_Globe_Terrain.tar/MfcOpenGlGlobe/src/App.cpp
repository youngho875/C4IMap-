#include "GlobeView.h"

class CMainFrame : public CFrameWnd {
protected:
    afx_msg int OnCreate(LPCREATESTRUCT cs) {
        if(CFrameWnd::OnCreate(cs)==-1) return -1;
        CCreateContext context{};
        context.m_pNewViewClass=RUNTIME_CLASS(CGlobeView);
        // No CDocument is needed for this renderer-only sample.
        CWnd* wnd=CreateView(&context);
        if(!wnd) return -1;
        SetActiveView(static_cast<CView*>(wnd));
        RecalcLayout();
        return 0;
    }
    DECLARE_MESSAGE_MAP()
};
BEGIN_MESSAGE_MAP(CMainFrame,CFrameWnd)
    ON_WM_CREATE()
END_MESSAGE_MAP()
class CGlobeApp : public CWinApp {
public:
    BOOL InitInstance() override {
        CWinApp::InitInstance();
        auto* frame=new CMainFrame;
        // CFrameWnd deletes itself if window creation fails.
        if(!frame->Create(nullptr,L"MFC OpenGL Globe",WS_OVERLAPPEDWINDOW,
            CRect(80,80,1360,900))) return FALSE;
        m_pMainWnd=frame;
        frame->ShowWindow(m_nCmdShow);
        frame->UpdateWindow();
        if(frame->GetActiveView()) frame->GetActiveView()->SetFocus();
        return TRUE;
    }
};
CGlobeApp theApp;
