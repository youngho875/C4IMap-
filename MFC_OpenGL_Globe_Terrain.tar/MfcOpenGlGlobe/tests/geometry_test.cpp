#include "../src/Geometry.h"
#include <cassert>
#include <iostream>
void verify(const geo::Mesh& m) {
    for(size_t i=0;i<m.indices.size();i+=3) {
        auto a=m.vertices.at(m.indices.at(i)).position;
        auto b=m.vertices.at(m.indices.at(i+1)).position;
        auto c=m.vertices.at(m.indices.at(i+2)).position;
        auto n=geo::cross(b-a,c-a);
        assert(geo::length(n)>1e-10);
        assert(geo::dot(n,a+b+c)>0);
    }
    for(auto& v:m.vertices) assert(std::abs(geo::length(v.normal)-1)<1e-9);
}
int main() {
    auto p=geo::position(0,0,1000);
    assert(std::abs(p.x-6372)<1e-9 && p.y==0 && p.z==0);
    auto globe=geo::globe(); verify(globe);
    auto g=geo::syntheticGrid();
    for(double e:{1.0,20.0}) {
        auto m=geo::terrain(g,e); verify(m);
        assert(m.indices.size()==size_t(g.cols-1)*(g.rows-1)*6);
        for(size_t i=0;i<m.vertices.size();++i)
            assert(std::abs(geo::length(m.vertices[i].position)-(6371+(g.meters[i]*e+50)/1000))<1e-8);
    }
    bool rejected=false;
    g.meters[0]=NAN;
    try { geo::terrain(g,1); } catch(const std::invalid_argument&) { rejected=true; }
    assert(rejected);
    std::cout<<"PASS: sphere radius, triangle winding, nondegenerate faces, normals, terrain scale, invalid data\n";
}
