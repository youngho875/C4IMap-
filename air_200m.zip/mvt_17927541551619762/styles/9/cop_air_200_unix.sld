﻿<?xml version="1.0" encoding="UTF-8"?>
<StyledLayerDescriptor version="1.0.0" xmlns="http://www.opengis.net/sld" xmlns:ogc="http://www.opengis.net/ogc" xmlns:xlink="http://www.w3.org/1999/xlink">
  <NamedLayer>
    <Name>wpth</Name>
    <UserStyle>
      <Title>wpth</Title>
      <FeatureTypeStyle>
        <Rule>
          <Name>rule_1</Name>
          <Title>위치통보점_점</Title>
          <MinScaleDenominator>100000</MinScaleDenominator>
          <MaxScaleDenominator>1999999</MaxScaleDenominator>
          <PointSymbolizer>
            <Graphic>
              <ExternalGraphic>
                <OnlineResource xlink:type="simple" xlink:href="symbols/symbol_1.png" />
                <Format>image/png</Format>
              </ExternalGraphic>
            </Graphic>
          </PointSymbolizer>
        </Rule>
      </FeatureTypeStyle>
    </UserStyle>
  </NamedLayer>
</StyledLayerDescriptor>