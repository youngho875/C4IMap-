<?xml version="1.0" encoding="UTF-8"?>
<StyledLayerDescriptor version="1.0.0" xmlns="http://www.opengis.net/sld" xmlns:ogc="http://www.opengis.net/ogc" xmlns:xlink="http://www.w3.org/1999/xlink">
    <NamedLayer>
        <Name>runway</Name>
        <UserStyle>
            <Title>runway</Title>
            <FeatureTypeStyle>
                <Rule>
                    <Name>rule_1</Name>
                    <Title>활주로_선</Title>
                    <MinScaleDenominator>100000</MinScaleDenominator>
                    <MaxScaleDenominator>6000000</MaxScaleDenominator>
                    <LineSymbolizer>
                        <Stroke>
                            <CssParameter name="stroke">#738CE6</CssParameter>
                            <CssParameter name="stroke-width">2</CssParameter>
                        </Stroke>
                    </LineSymbolizer>
                </Rule>
            </FeatureTypeStyle>
        </UserStyle>
    </NamedLayer>
</StyledLayerDescriptor>
