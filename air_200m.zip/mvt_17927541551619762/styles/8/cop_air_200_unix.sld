<?xml version="1.0" encoding="UTF-8"?>
<StyledLayerDescriptor version="1.0.0" xmlns="http://www.opengis.net/sld" xmlns:ogc="http://www.opengis.net/ogc" xmlns:xlink="http://www.w3.org/1999/xlink">
    <NamedLayer>
        <Name>suas</Name>
        <UserStyle>
            <Title>suas</Title>
            <FeatureTypeStyle>
                <Rule>
                    <Name>rule_1</Name>
                    <Title>특수사용공역_선</Title>
                    <MinScaleDenominator>100000</MinScaleDenominator>
                    <MaxScaleDenominator>6000000</MaxScaleDenominator>
                    <LineSymbolizer>
                        <Stroke>
                            <CssParameter name="stroke">#5E3AE6</CssParameter>
                            <CssParameter name="stroke-width">1</CssParameter>
                        </Stroke>
                    </LineSymbolizer>
                </Rule>
            </FeatureTypeStyle>
        </UserStyle>
    </NamedLayer>
</StyledLayerDescriptor>
