# MFC + OpenGL 지구 / 지형 샘플

## 포함 기능

- CWinApp → CFrameWnd → CView 기반 독립 실행 Windows 프로그램
- CS_OWNDC 윈도우 클래스 및 전용 HDC
- ChoosePixelFormat / SetPixelFormat / wglCreateContext / wglMakeCurrent
- 깊이 버퍼, 더블 버퍼, 조명, 삼각형 메시, SwapBuffers
- 종료 시 디스플레이 리스트 삭제, 컨텍스트 해제, HDC 반환
- 반지름 6,371km의 구형 지구, 경위선
- 경도 124~132°, 위도 33~39° 영역에 가상 고도 지형 생성
- 161 × 121 정점, 38,400개 지형 삼각형
- 실제 삼각형으로부터 계산한 지형 법선 및 고도별 색상
- 지구 전체 / 지형 확대 카메라, 마우스 드래그 / 휠

실제 고도와 NaturalEarthII 영상 파일 자체는 포함하지 않습니다. NaturalEarthII 폴더를 연결하면 지표 영상이 표시됩니다. 기본 파란 구체는 지구 기준면이며,
그 위의 직사각형 지형은 알고리즘으로 만든 가상 데이터입니다.
이 프로젝트는 지형 렌더러의 시작점이며 완성된 GIS 엔진이 아닙니다.

## 1. 개발 환경

- Windows 10/11 x64
- Visual Studio 2022, C++ 데스크톱 개발 워크로드
- Visual Studio Installer의 개별 구성 요소에서 v143용 C++ MFC(x86 및 x64) 설치
- Windows SDK, CMake 3.21 이상
- C++17, Unicode, 동적 MFC /MD 또는 /MDd

freeglut, GLFW, GLEW, GDAL은 필요하지 않습니다. Windows OpenGL/GLU를 사용합니다.
빌드에 필요한 구성 요소가 이미 설치되어 있으면 네트워크 없이 빌드할 수 있습니다.

## 2. 빌드와 실행

압축을 해제한 후 'Developer Command Prompt for VS 2022'에서:

```bat
cd MfcOpenGlGlobe
build_vs2022.bat
build\Release\MfcOpenGlGlobe.exe
```

직접 생성하려면:

```bat
cmake -S . -B build -G "Visual Studio 17 2022" -A x64
cmake --build build --config Release
```

생성된 build/MfcOpenGlGlobe.sln을 Visual Studio에서 열어 디버깅할 수 있습니다.
다른 PC에서 실행하려면 해당 VC++/MFC 런타임과 그래픽 드라이버가 필요합니다.

## 3. 조작

| 입력 | 동작 |
|---|---|
| 왼쪽 드래그 | 지구 시점 이동 / 지형 주변 궤도 회전 |
| 마우스 휠 | 확대·축소 |
| 1 | 지구 전체 보기, 한반도 부근을 중앙에 배치 |
| 2 | 가상 지형 확대 보기 |
| W | 지형 면 / 와이어프레임 전환 |
| G | 경위선 표시 전환 |
| E | 고도 과장 1배 / 20배 전환 |

처음 실행하면 지구 전체가 나타납니다. 지형을 자세히 보려면 2를 누르세요.
기본 고도 과장은 20배입니다. 정확한 크기 비교에는 E를 눌러 1배로 바꾸세요.
지형 카메라는 고정된 데모 영역 중심을 바라봅니다. 일반적인 지형 추적·충돌 카메라는 아닙니다.

## 4. 소스 구성

| 파일 | 역할 |
|---|---|
| src/App.cpp | MFC 애플리케이션 및 프레임, CView 생성 |
| src/GlobeView.h/.cpp | WGL 수명 관리, 렌더링, 카메라, 입력 |
| src/Geometry.h | 구면 좌표 변환, 지구 및 지형 메시 생성 |
| tests/geometry_test.cpp | 플랫폼 독립 기하 검증 |
| CMakeLists.txt | Visual Studio 프로젝트 생성 설정 |

## 5. 렌더링 컨텍스트 흐름

CGlobeView::PreCreateWindow에서 CS_OWNDC를 지정합니다.
OnCreate → InitGL에서 HDC 획득 → 픽셀 포맷 선택/설정 → HGLRC 생성 → 현재 컨텍스트 지정 순서로 실행합니다.
픽셀 포맷은 해당 윈도우에 한 번만 설정합니다.

```cpp
dc_ = ::GetDC(m_hWnd);
int format = ChoosePixelFormat(dc_, &pfd);
SetPixelFormat(dc_, format, &pfd);
rc_ = wglCreateContext(dc_);
wglMakeCurrent(dc_, rc_);
```

위 코드는 흐름 요약이며 실제 소스에는 반환값 검사가 있습니다.
OnDraw에서 Render를 호출합니다. OpenGL 호출 전에 컨텍스트를 현재 스레드에 연결하고,
렌더링 종료 후 SwapBuffers로 표시합니다. 창 크기는 OnSize에서 저장합니다.
모든 OpenGL 작업은 UI 스레드에서 실행합니다.

OnDestroy에서 리스트 삭제 → wglMakeCurrent(nullptr,nullptr) → wglDeleteContext → ReleaseDC 순서로 정리합니다.
부분 초기화 실패도 같은 정리 함수를 사용합니다.

## 6. 지구 및 지형 좌표

경도 λ, 위도 φ, 고도 h(m)에서:

```text
r = 6371.0 + h / 1000.0
x = r × cos(φ) × cos(λ)
y = r × cos(φ) × sin(λ)
z = r × sin(φ)
```

삼각함수 입력은 라디안이고 렌더링 좌표 단위는 km입니다.
X축: 경도 0° 적도, Y축: 동경 90° 적도, Z축: 북극.

이것은 구형 지구 좌표입니다. WGS84 타원체 ECEF 변환과 동일하지 않습니다.
지형에 전달하는 고도도 이 샘플 구체에 대한 높이입니다.
실제 정밀 GIS에는 WGS84 타원체 변환 및 고도 기준 통일이 필요합니다.

지구는 1° 간격 메시입니다. 가상 지형은 0.05° 간격입니다.
경위도 격자의 동서 간격은 위도에 따라 달라지며 고정된 미터 간격을 사용하지 않습니다.
기본면과의 겹침을 방지하기 위해 지형에 표시용 50m 오프셋을 더합니다.
이 값은 원본 고도 데이터나 계산용 고도에 반영하지 않아야 합니다.
현재 구성은 바다 기준면 위에 지형을 얹는 방식이므로 음수 고도와 지하 지형은 지원하지 않습니다.

## 7. 실제 DTED / GeoTIFF 고도 연결 지점

OnCreate의 다음 부분을 교체합니다.

```cpp
heights_ = geo::syntheticGrid();
```

사용할 인터페이스:

```cpp
geo::HeightGrid grid;
grid.cols = 257;
grid.rows = 257;
grid.west = 127.0;
grid.east = 128.0;
grid.south = 36.0;
grid.north = 37.0;
grid.meters.resize(size_t(grid.cols) * grid.rows);
// 여기에 리샘플링한 실제 높이(m)를 입력합니다.
// grid.meters[row * grid.cols + col] = height;
// row=0: 남쪽, row=rows-1: 북쪽
// col=0: 서쪽, col=cols-1: 동쪽
heights_ = std::move(grid);
```

위 예제에서 높이를 채우지 않으면 평면 고도 타일이 됩니다.
범위는 정점의 경위도, 즉 첫/마지막 샘플 위치를 의미합니다.
GDAL GeoTransform의 래스터 외곽 범위와 픽셀 중심 좌표를 혼동하지 마세요.
일반적으로 래스터는 북쪽 행부터 저장되므로 행 방향을 변환해야 합니다.
회전된 래스터나 투영 좌표계 자료는 먼저 경위도 규칙 격자로 재투영·리샘플링하세요.
NoData는 메시 생성 전에 마스킹/보간해야 합니다. 이 샘플은 비유한 값과 음수 고도를 거부합니다.

DTED/DEM의 해발고도와 타원체고는 기준이 다를 수 있습니다.
타원체 기반 엔진으로 확장할 때는 지오이드 보정 등을 통해 수직 기준을 맞추세요.
본 샘플에는 DTED 바이너리 파서와 GDAL 파일 로더가 포함되어 있지 않습니다.

데이터 범위를 바꿀 경우 Render의 지역 카메라 중심(128°,36°)과
지구 카메라의 lon_/lat_도 변경해야 합니다.
런타임 메시 갱신은 UI 스레드에서 wglMakeCurrent 성공 후 RebuildTerrain을 호출하세요.

## 8. 기존 MFC SDI 프로젝트로 옮기기

1. Geometry.h와 GlobeView.h/.cpp를 추가합니다.
2. 문서 템플릿의 View 런타임 클래스를 RUNTIME_CLASS(CGlobeView)로 지정합니다.
3. 프로젝트가 미리 컴파일된 헤더를 강제하면 GlobeView.cpp 맨 앞에 pch.h를 추가하거나 해당 파일에서 PCH 사용을 해제합니다.
4. C++17, Unicode, NOMINMAX를 설정합니다.
5. 링커 입력에 opengl32.lib, glu32.lib, windowscodecs.lib, ole32.lib를 추가합니다.
   TextureLoader.h/.cpp도 추가하고, 기존 앱의 InitInstance에서 AfxOleInit() 성공을 확인합니다.
6. 기존 프로그램에 App.cpp는 추가하지 않습니다. 기존 CWinApp/CMainFrame을 유지합니다.

본 독립 샘플은 CDocument 없이 CFrameWnd::CreateView로 뷰를 생성합니다.
파일 열기/저장 및 인쇄 명령은 제공하지 않습니다.

## 9. 검증 범위와 확장 제한

이 제공 환경은 Linux이므로 MFC 컴파일 및 Windows GUI 실행은 검증하지 못했습니다.
플랫폼 독립 Geometry.h는 g++ C++17로 컴파일하여 다음 검사를 통과했습니다.

- 구체 반지름과 고도 단위 변환
- 지구/지형 삼각형의 바깥쪽 방향
- 극점을 포함한 비퇴화 삼각형
- 정규화된 법선
- 고도 과장 1배/20배의 정점 거리
- NaN 고도 거부

Windows에서 Release x64 빌드 후 창 크기 변경, 1/2 전환, 드래그/휠,
W/G/E 전환과 창 종료를 확인하세요.

OpenGL 고정 기능 파이프라인/디스플레이 리스트를 사용한 교육용 시작 프로젝트입니다.
대용량 GIS는 VBO/VAO/셰이더, 타일 LOD, 비동기 로딩, 카메라 상대 좌표,
정밀 깊이 처리 및 지형 충돌 처리로 확장해야 합니다.
현재 경위선에도 가시성을 위한 표시용 1km 오프셋을 사용합니다.

## 참고 문서

- https://learn.microsoft.com/en-us/windows/win32/api/wingdi/nf-wingdi-wglcreatecontext
- https://learn.microsoft.com/en-us/windows/win32/api/wingdi/nf-wingdi-wglmakecurrent
- https://wikis.khronos.org/opengl/Creating_an_OpenGL_Context
- https://cmake.org/cmake/help/latest/variable/CMAKE_MFC_FLAG.html


## 10. 추가 기능: Cesium NaturalEarthII 매핑

Cesium 배포본의 `Assets/Textures/NaturalEarthII` 폴더를 그대로 사용합니다.
예: `Cesium/Build/Cesium/Assets/Textures/NaturalEarthII`.
이 파일에는 영상 데이터를 재배포하지 않습니다. 사용 중인 Cesium의 로컬 폴더를 지정하세요.

실행 후 T 키 → 폴더 선택 창에서 **NaturalEarthII 폴더 자체**를 선택합니다.
그 안의 0, 1, 2 폴더나 개별 JPG를 선택하는 것이 아닙니다.
또는 exe 옆에 NaturalEarthII 폴더를 복사하면 시작 시 자동으로 읽습니다.
exe 옆 Assets/Textures/NaturalEarthII 경로도 자동 인식합니다.

| 키 | 추가 기능 |
|---|---|
| T | NaturalEarthII 폴더 선택 / 다시 로드 |
| I | 영상 매핑 켜기·끄기 |
| H | 가상 지형 표시·숨김 |

필수 폴더 예시(최소 Level 0):

- NaturalEarthII/0/0/0.jpg: 서반구
- NaturalEarthII/0/1/0.jpg: 동반구
- NaturalEarthII/tilemapresource.xml: Cesium 원본 메타데이터(본 로더는 파싱하지 않음)

원본 Cesium NaturalEarthII 규격에 특화된 로더입니다.
EPSG:4326 geodetic, 256x256 JPG, TMS의 남쪽 원점, Level 0~2를 지원합니다.
WebMercator/XYZ/다른 TMS 규격은 지원하지 않습니다.

| 레벨 | 타일 개수(X × Y) | 합성 영상 |
|---|---|---|
| 0 | 2 × 1 | 512 × 256 |
| 1 | 4 × 2 | 1024 × 512 |
| 2 | 8 × 4 | 2048 × 1024 |

가장 높은 완전한 레벨(2→1→0)을 선택하고 GPU 최대 텍스처 크기를 확인합니다.
파일 누락 시 더 낮은 레벨을 시도합니다. 선택한 레벨의 JPG가 손상되었거나 크기가 다르면
로드 오류를 표시하고 기존 텍스처를 유지합니다.
JPG는 Windows WIC로 RGBA 디코딩하므로 외부 이미지 라이브러리가 필요 없습니다.

TMS 타일 y=0은 남쪽이고 JPG의 첫 행은 북쪽입니다.
타일의 남북 순서를 유지하고 각 JPG 내부의 행을 뒤집어 OpenGL 이미지로 합칩니다.
구체와 지형의 UV는 다음과 같습니다.

```cpp
u = (longitudeDegrees + 180.0) / 360.0;
v = (latitudeDegrees + 90.0) / 180.0;
```

따라서 동경 0°는 u=0.5, 적도는 v=0.5입니다.
텍스처는 구체와 가상 지형에 동일한 좌표 기준으로 적용됩니다.
텍스처 사용 시 GL_REPLACE로 원본 색상을 표시하고 조명·고도색의 변조를 피합니다.
I를 눌러 영상을 끄면 이전 고도별 색상/조명이 표시됩니다.
NaturalEarthII는 저해상도 전지구 지도이므로 지형 확대 화면에서는 흐리게 보일 수 있습니다.
확대에 따른 동적 타일 LOD는 구현하지 않습니다.

## 11. 추가 기능: 마우스 이동 경위도 HUD

마우스가 이동하면 화면 상단에 예를 들어 다음을 표시합니다.

`Lon: +128.000000 deg   Lat: +36.000000 deg   [terrain mesh]`

- 양의 경도: 동경, 음의 경도: 서경
- 양의 위도: 북위, 음의 위도: 남위
- 구체만 맞으면 `[reference sphere]`
- 표시 중인 지형 메시가 더 가까우면 `[terrain mesh]`
- 우주 배경이나 뷰 바깥이면 `Lon: -- Lat: --`
- 소수점 6자리는 표시 형식이며 측정 정확도를 뜻하지 않습니다.

`OnMouseMove` → 마우스 픽셀 저장 → 다시 그리기 → `gluUnProject`로 near/far 점 계산
→ 광선/기준 구체 및 광선/지형 삼각형 교차 → 가장 가까운 교차점 → 경위도 변환
→ OpenGL HUD 표시 순서입니다.

Windows 화면 좌표는 위쪽이 원점이므로 `y = height - mouseY - 0.5`로 바꿉니다.
픽셀 중심(x+0.5)을 사용합니다. 드래그/줌/고도 배율/지형 표시 변경 후에도
현재 카메라 행렬을 사용하여 좌표를 다시 계산합니다.
마우스 이탈 메시지로 이전 좌표가 남지 않게 처리합니다.
HUD는 OpenGL 정사영과 WGL 글꼴 디스플레이 리스트를 사용하며 SwapBuffers 전에 그립니다.

기본 구체 교차는 분석적 반지름 6371km 구체를 사용합니다. 1도 간격 렌더링 메시와는
작은 차이가 있을 수 있습니다. 지형 교차는 화면에 표시한 고도 과장 및 50m 오프셋을
포함하는 삼각형 메시를 사용합니다. 따라서 실제 DEM 표면에 대한 정밀 측정 기능이 아닙니다.
와이어프레임에서도 선택은 삼각형의 면을 기준으로 계산합니다.
지형을 H로 숨기면 지구 기준면만 선택합니다.

약 38,400개 삼각형을 선형 검사하는 데모 구현입니다. 대용량 지형에는 BVH/쿼드트리로
교차 후보를 줄이거나 깊이 버퍼 기반 피킹을 구현하세요.

추가 자동 검사: 전지구/지형 UV 방향, 알려진 경위도 및 북극 광선 교차,
우주 배경 미교차, 지형 우선 교차, 지구 뒤쪽 지형의 가림 처리.
WIC 디코딩, MFC 빌드, 폴더 대화상자 및 HUD 화면은 Windows 실행 검증이 필요합니다.

추가 참고:
- https://github.com/CesiumGS/cesium-google-earth-examples/blob/main/Cesium/Assets/Textures/NaturalEarthII/tilemapresource.xml
- https://learn.microsoft.com/en-us/windows/win32/wic/-wic-creating-decoder
