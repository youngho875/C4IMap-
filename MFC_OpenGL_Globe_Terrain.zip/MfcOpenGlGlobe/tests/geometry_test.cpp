#include "../src/Geometry.h"
#include <cassert>
#include <iostream>
void verify(const geo::Mesh& m) {
    for(size_t i=0;i<m.indices.size();i+=3) {
        auto a=m.vertices.at(m.indices.at(i)).position;
        auto b=m.vertices.at(m.indices.at(i+1)).position;
        auto c=m.vertices.at(m.indices.at(i+2)).position;
        auto n=geo::cross(b-a,c-a);
        assert(geo::length(n)>1e-10);
        assert(geo::dot(n,a+b+c)>0);
    }
    for(auto& v:m.vertices) assert(std::abs(geo::length(v.normal)-1)<1e-9);
}
int main() {
    auto p=geo::position(0,0,1000);
    assert(std::abs(p.x-6372)<1e-9 && p.y==0 && p.z==0);
    auto globe=geo::globe(); verify(globe);
    // Texture coordinates: west/east seam, south/north orientation.
    assert(globe.vertices.front().u==0 && globe.vertices.front().v==0);
    assert(globe.vertices.back().u==1 && globe.vertices.back().v==1);
    geo::Mesh empty;
    auto pole=geo::pickSurface({0,0,10000},{0,0,-1},empty);
    assert(pole.hit && !pole.terrain);
    assert(std::abs(geo::geographic(pole.position).lat-90)<1e-8);
    assert(!geo::pickSurface({10000,0,0},{0,1,0},empty).hit);
    auto radial=geo::unit(geo::position(128,36));
    auto earth=geo::pickSurface(radial*10000,radial*(-1),empty);
    auto ll=geo::geographic(earth.position);
    assert(earth.hit && std::abs(ll.lon-128)<1e-8 && std::abs(ll.lat-36)<1e-8);
    auto g=geo::syntheticGrid();
    for(double e:{1.0,20.0}) {
        auto m=geo::terrain(g,e); verify(m);
        auto hit=geo::pickSurface(radial*10000,radial*(-1),m);
        assert(hit.hit && hit.terrain);
        auto opposite=geo::pickSurface(radial*(-10000),radial,m);
        assert(opposite.hit && !opposite.terrain); // hidden terrain must not win
        assert(std::abs(m.vertices.front().u-(124.0+180)/360)<1e-12);
        assert(std::abs(m.vertices.front().v-(33.0+90)/180)<1e-12);
        assert(m.indices.size()==size_t(g.cols-1)*(g.rows-1)*6);
        for(size_t i=0;i<m.vertices.size();++i)
            assert(std::abs(geo::length(m.vertices[i].position)-(6371+(g.meters[i]*e+50)/1000))<1e-8);
    }
    bool rejected=false;
    g.meters[0]=NAN;
    try { geo::terrain(g,1); } catch(const std::invalid_argument&) { rejected=true; }
    assert(rejected);
    std::cout<<"PASS: sphere radius, triangle winding, nondegenerate faces, normals, terrain scale, invalid data, UV, ray picks, occlusion\n";
}
