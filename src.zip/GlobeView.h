#pragma once
#include <afxwin.h>
#include <gl/GL.h>
#include "Geometry.h"
#include "BaseMapConfig.h"
#include "ShapeLayer.h"
#include <filesystem>
#include <string>
#include <memory>
#include <vector>
#include <atlconv.h>


class CGlobeView : public CView 
{
    DECLARE_DYNCREATE(CGlobeView)
public:
    CGlobeView() = default;
    ~CGlobeView() override;
    BOOL PreCreateWindow(CREATESTRUCT& cs) override;
    void OnDraw(CDC*) override;
protected:
    afx_msg int OnCreate(LPCREATESTRUCT cs);
    afx_msg void OnDestroy();
    afx_msg void OnSize(UINT type,int cx,int cy);
    afx_msg BOOL OnEraseBkgnd(CDC*);
    afx_msg void OnLButtonDown(UINT flags,CPoint p);
    afx_msg void OnLButtonUp(UINT flags,CPoint p);
    afx_msg void OnMouseMove(UINT flags,CPoint p);
    afx_msg BOOL OnMouseWheel(UINT flags,short delta,CPoint p);
    afx_msg void OnKeyDown(UINT key,UINT repeat,UINT flags);
    afx_msg void OnMouseLeave();
    afx_msg void OnCaptureChanged(CWnd* wnd);
    DECLARE_MESSAGE_MAP()

private:
    //ShapeLayer baseMapLayers_;
    //void OpenShapeFile();
    BaseMapConfig baseMapConfig_;
    std::vector<std::unique_ptr<ShapeLayer>> baseMapLayers_;

    void LoadBaseMapXml(const std::filesystem::path& filename);

private:
    HDC dc_=nullptr;
    HGLRC rc_=nullptr;
    GLuint globeList_=0,terrainList_=0,texture_=0,fontList_=0;
    bool textureEnabled_=true,terrainVisible_=true,mouseInside_=false;
    CPoint mouse_;
    geo::Mesh terrainMesh_;
    CString textureStatus_=L"NaturalEarthII 미설정 (T:폴더 선택)";
    std::string coordinateText_="Lon: --  Lat: --";
    int width_=1,height_=1;
    bool dragging_ = false;
    bool local_ = false;
    bool wire_ = false;
    bool grid_ = false;
    CPoint last_;
    double lon_ = 128;
    double lat_ = 36;
    double distance_ = 20000;
    double azimuth_ = 0;
    double tilt_ = 30;
    double exaggeration_ = 20;
    geo::HeightGrid heights_;
    bool InitGL();
    void ReleaseGL();
    void RebuildTerrain();
    static GLuint CompileMesh(const geo::Mesh& mesh);
    void Render();
    void DrawGrid();
    void UpdateTitle();
    void SelectTextureFolder();
    void LoadTexture(const std::filesystem::path& path,bool reportError);
    void AutoLoadTexture();
    void InitHudFont();
    void UpdateMouseCoordinates();
    void DrawHud();
};
